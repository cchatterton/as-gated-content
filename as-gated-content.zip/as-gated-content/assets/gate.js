(function () {
    'use strict';

    var STORAGE_KEY = 'asgc_gate_state';
    var gate = document.querySelector('[data-asgc-gate]');

    if (!gate) {
        return;
    }

    var config = {
        gateId: gate.getAttribute('data-gate-id'),
        postId: gate.getAttribute('data-post-id'),
        formId: gate.getAttribute('data-form-id'),
        trigger: gate.getAttribute('data-trigger') || 'entrance',
        delay: parseInt(gate.getAttribute('data-delay') || '0', 10),
        threshold: parseInt(gate.getAttribute('data-threshold') || '0', 10),
        debugMode: gate.getAttribute('data-debug-mode') === '1',
        previewMode: gate.getAttribute('data-preview-mode') === '1'
    };

    var dialog = gate.querySelector('.asgc-gate__dialog');
    var closeButton = gate.querySelector('[data-asgc-close]');
    var debugPanel = document.querySelector('[data-asgc-debug]');
    var hasDisplayed = false;
    var openTimer = null;
    var lastMouseY = null;
    var lastMouseMoveAt = 0;
    var lastExitIntentAt = 0;
    var previousFocus = null;

    function readState() {
        try {
            return JSON.parse(window.localStorage.getItem(STORAGE_KEY)) || { submitted: {}, triggers: {} };
        } catch (error) {
            return { submitted: {}, triggers: {} };
        }
    }

    function writeState(state) {
        try {
            window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
        } catch (error) {
            return;
        }
    }

    function getTriggerKey() {
        return config.gateId + ':post:' + config.postId;
    }

    function markSubmitted() {
        var state = readState();
        state.submitted = state.submitted || {};
        state.submitted[config.gateId] = true;
        writeState(state);
        closeGate();
    }

    function isSubmitted() {
        if (config.previewMode) {
            return false;
        }

        var state = readState();
        return !!(state.submitted && state.submitted[config.gateId]);
    }

    function recordTriggerAndShouldShow() {
        if (config.previewMode) {
            return true;
        }

        var state = readState();
        var triggerKey = getTriggerKey();

        state.triggers = state.triggers || {};
        state.triggers[triggerKey] = parseInt(state.triggers[triggerKey] || '0', 10) + 1;
        writeState(state);

        return state.triggers[triggerKey] > config.threshold;
    }

    function openGate() {
        if (hasDisplayed || isSubmitted()) {
            return;
        }

        hasDisplayed = true;
        previousFocus = document.activeElement;
        gate.classList.add('is-open');
        gate.setAttribute('aria-hidden', 'false');
        document.body.classList.add('asgc-gate-open');

        if (dialog) {
            dialog.focus();
        }
    }

    function closeGate() {
        gate.classList.remove('is-open');
        gate.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('asgc-gate-open');

        if (previousFocus && typeof previousFocus.focus === 'function') {
            previousFocus.focus();
        }
    }

    function maybeOpenGate() {
        if (hasDisplayed || isSubmitted()) {
            return;
        }

        if (!recordTriggerAndShouldShow()) {
            return;
        }

        if (openTimer) {
            return;
        }

        openTimer = window.setTimeout(function () {
            openTimer = null;
            openGate();
        }, Math.max(0, config.delay) * 1000);
    }

    function resetBrowserState() {
        var state = readState();

        state.submitted = state.submitted || {};
        state.triggers = state.triggers || {};
        delete state.submitted[config.gateId];
        delete state.triggers[getTriggerKey()];
        writeState(state);
    }

    function bindDebugPanel() {
        if (!debugPanel) {
            return;
        }

        var showButton = debugPanel.querySelector('[data-asgc-debug-show]');
        var resetButton = debugPanel.querySelector('[data-asgc-debug-reset]');

        if (showButton) {
            showButton.addEventListener('click', function () {
                resetBrowserState();
                openGate();
            });
        }

        if (resetButton) {
            resetButton.addEventListener('click', resetBrowserState);
        }
    }

    function bindExitIntent() {
        var triggerDebounce = 750;
        var html = document.documentElement;

        function getTopBoundary() {
            var adminBar = document.getElementById('wpadminbar');
            var adminBarHeight = adminBar ? adminBar.getBoundingClientRect().height : 0;

            return adminBarHeight + 80;
        }

        function triggerExitIntent() {
            if (hasDisplayed || isSubmitted()) {
                return;
            }

            if (Date.now() - lastExitIntentAt < triggerDebounce) {
                return;
            }

            lastExitIntentAt = Date.now();
            maybeOpenGate();
        }

        function isMousePointer(event) {
            return !event.pointerType || 'mouse' === event.pointerType;
        }

        document.addEventListener('mousemove', function (event) {
            var previousMouseY = lastMouseY;
            var topBoundary = getTopBoundary();

            lastMouseY = event.clientY;
            lastMouseMoveAt = Date.now();

            if (null === previousMouseY) {
                return;
            }

            if (event.clientY <= topBoundary && previousMouseY - event.clientY >= 4) {
                triggerExitIntent();
            }
        }, { passive: true });

        document.addEventListener('mouseout', function (event) {
            var topBoundary = getTopBoundary();

            if (event.relatedTarget || event.toElement) {
                return;
            }

            if (event.clientY <= topBoundary || event.clientY <= 0) {
                triggerExitIntent();
            }
        }, { passive: true });

        html.addEventListener('mouseleave', function (event) {
            var topBoundary = getTopBoundary();

            if (event.clientY <= topBoundary || event.clientY <= 0) {
                triggerExitIntent();
            }
        }, { passive: true });

        if (window.PointerEvent) {
            html.addEventListener('pointerleave', function (event) {
                var topBoundary = getTopBoundary();

                if (isMousePointer(event) && (event.clientY <= topBoundary || event.clientY <= 0)) {
                    triggerExitIntent();
                }
            }, { passive: true });
        }

        window.addEventListener('blur', function () {
            var topBoundary = getTopBoundary();
            var pointerWasRecentlyNearTop = lastMouseY !== null && lastMouseY <= topBoundary && Date.now() - lastMouseMoveAt < 750;

            if (pointerWasRecentlyNearTop) {
                triggerExitIntent();
            }
        });
    }

    if (closeButton) {
        closeButton.addEventListener('click', closeGate);
    }

    bindDebugPanel();

    document.addEventListener('keydown', function (event) {
        if ('Escape' === event.key && gate.classList.contains('is-open')) {
            closeGate();
        }
    });

    var existingConfirmationCallback = window.gform_confirmation_loaded;

    window.gform_confirmation_loaded = function (formId) {
        if (typeof existingConfirmationCallback === 'function') {
            existingConfirmationCallback(formId);
        }

        if (String(formId) === String(config.formId)) {
            markSubmitted();
        }
    };

    var observer = new MutationObserver(function () {
        if (gate.querySelector('.gform_confirmation_message')) {
            markSubmitted();
        }
    });

    observer.observe(gate, { childList: true, subtree: true });

    if (config.debugMode && window.console) {
        window.console.info('AS Gate resolved', config, readState());
    }

    if (config.previewMode) {
        window.setTimeout(openGate, 250);
        return;
    }

    if (isSubmitted()) {
        if (config.debugMode && window.console) {
            window.console.info('AS Gate suppressed because this gate is marked submitted in localStorage.');
        }
        return;
    }

    if ('exit' === config.trigger) {
        bindExitIntent();
    } else {
        window.setTimeout(maybeOpenGate, 0);
    }
})();
