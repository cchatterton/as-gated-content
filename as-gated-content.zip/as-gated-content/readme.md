# AS Gated Content

Reusable gated content overlays for WordPress, built for AlphaSys.

## Requirements

- WordPress 6.0+
- PHP 8.1+
- ACF Pro
- Gravity Forms

## Features

- Gate and Gate Rule custom post types.
- ACF local field groups registered from code.
- Page-level gates for public content types.
- Post type fallback rules.
- Entrance and desktop exit-intent triggers.
- Delay and trigger-threshold controls.
- Visitor suppression after successful Gravity Forms submission.
- Native GitHub release updater support.

## Controller integration — 0.2.6

Remove independent GitHub update checks and delegate updates to AlphaSys Update Controller. Keep Beta readiness and existing feature settings, package identity and domain restrictions. Previous standalone GitHub update instructions are superseded.
